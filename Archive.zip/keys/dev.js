module.exports = {
    JWT_SECRET_KEY: 'haiyowangi-secret-key',
    WEB_EMAIL_ACCOUNT: "no-reply@haiyowangi.com",
    WEB_EMAIL_PASSWORD: "k4t4s4nd118",
    DB_HOST: "localhost",
    DB_USER: "root",
    DB_PASSWORD: "",
    DB_NAME: "db_hw"
}