const FETCH_REQUEST_TYPES = require('./fetch.req.types')
const ERROR_CODE = require('./res.error.types')
const RES_TYPES = require('./res.types')

module.exports = {
    FETCH_REQUEST_TYPES,
    ERROR_CODE,
    RES_TYPES
}