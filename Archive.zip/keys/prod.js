module.exports = {
    JWT_SECRET_KEY: process.env.JWT_SECRET_KEY,
    WEB_EMAIL_ACCOUNT: process.env.WEB_EMAIL_ACCOUNT,
    WEB_EMAIL_PASSWORD: process.env.WEB_EMAIL_PASSWORD,
    DB_HOST: process.env.DB_HOST,
    DB_USER: process.env.DB_USER,
    DB_PASSWORD: process.env.DB_PASSWORD,
    DB_NAME: process.env.DB_NAME
}