module.exports = {
    jwtStrategy: require("./jwtStrategy")
}